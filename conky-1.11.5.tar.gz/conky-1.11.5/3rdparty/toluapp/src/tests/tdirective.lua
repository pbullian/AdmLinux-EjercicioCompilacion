assert(a==3)
assert(A==4)
assert(func()==5)

print("Directive test OK")

